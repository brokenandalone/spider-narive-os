# Spider OS native architecture

## Boundary

Spider OS is a traditional mutable Linux installation, not a website packaged
as an application and not an Atomic/OSTree host. The ISO installs an ordinary
Fedora KDE system whose root filesystem can be administered normally.

| Layer | Implementation | Responsibility |
| --- | --- | --- |
| Base OS | Fedora KDE Live / Anaconda | Kernel, systemd, KDE Plasma, graphics, updates, writable root |
| Resident core | `spiderd` C++ daemon | Local readiness, health state, future resident-agent boundary |
| Control CLI | `spiderctl` C++ CLI | Human- and test-readable local diagnostics |
| Desktop shell | `spider-shell` Qt6 Widgets | Native launch surface and Webbie presence indicator |
| Session integration | systemd + KDE autostart | Starts the resident core and native shell |
| Installer | Fedora Live ISO + `mkksiso` | Produces a real Anaconda installer ISO |

## Boot flow

1. Fedora's bootloader starts the real Linux host and systemd.
2. `spider-os.service` starts `spiderd` as the unprivileged `spider` user.
3. `spiderd` creates `/run/spider-os/webbie.sock`, writes the readiness marker,
   and serves a small allow-listed status protocol.
4. KDE Plasma starts normally.
5. KDE launches `spider-shell`, which calls `spiderctl status` and displays the
   resident state.

The desktop can still be used when Webbie is unavailable. A resident assistant
must not become a single point of failure for login, the file manager, the
terminal, or system recovery.

## Native protocol

The socket accepts only these commands:

- `status` or `health` — JSON health response.
- `ping` — liveness response.
- `hello` — a short resident greeting.

There is no HTTP listener in the foundation. The socket is local to the host,
and the service restricts its address family to `AF_UNIX`.

## Security posture

- The daemon is not root.
- The daemon has no network socket and no network dependency for readiness.
- The socket exposes status only in this milestone.
- systemd applies filesystem, privilege, kernel, and address-family limits.
- Future AI connectors must be opt-in and must not receive arbitrary host
  command execution by default.

## Writable-system rule

The first Spider OS version must remain writable after installation:

- `/`, `/usr`, and `/etc` are ordinary writable filesystems.
- `dnf` and normal RPM installation are supported.
- `systemctl enable`, `systemctl edit`, and local configuration changes work.
- There is no bootc deployment, OSTree commit, transient overlay, or automatic
  image reset on reboot.

Backups and rollback can be added later as optional tools, but they must not
turn the host into a read-only image.

## Deliberate non-goals for milestone 0.1

- No browser shell or embedded web view.
- No cloud account requirement for boot or login.
- No Kali tools in the base image.
- No AI model download during image build.
- No automatic destructive disk installation.
