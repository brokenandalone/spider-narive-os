# Spider OS — Native Foundation

Spider OS is a real bootable Linux distribution built as a traditional,
mutable Fedora KDE installation. It uses the normal Fedora kernel, systemd,
KDE Plasma, RPM packages, and Anaconda installer. The installed system has a
writable root filesystem; it is not an Atomic, OSTree, bootc, or read-only
host.

This is the clean restart. The system does not depend on Electron, a PWA, a
browser window, JavaScript, or a local HTTP server to provide the desktop.

## What exists in this foundation

- Fedora KDE provides the actual Linux system and KDE Plasma desktop.
- `spiderd` is a compiled C++ resident service managed by systemd.
- `spiderctl` is a compiled local diagnostic CLI.
- `spider-shell` is a compiled Qt6 desktop application launched by KDE.
- Webbie's first transport is a local Unix socket, not a web page.
- The system service is restricted to local Unix-socket communication and runs
  as an unprivileged `spider` account.
- The host remains writable through normal Fedora administration tools such as
  `dnf`, `systemctl`, and direct edits under `/etc`.

The first milestone deliberately proves the operating-system boundary. AI
providers, voice, search indexing, media tools, and the Kali lab are later
layers. They do not get to decide whether the base operating system boots.

## Build the native components

On Fedora or another RPM-based development machine:

```bash
sudo dnf install cmake gcc-c++ ninja-build pkgconf-pkg-config qt6-qtbase-devel lorax curl
./build-native.sh
```

This creates `output/spider-native-root`, a staged root tree containing the
compiled native programs and system files.

## Build the installer ISO

The ISO builder starts from the current Fedora KDE Live ISO and adds the native
Spider OS payload plus an Anaconda Kickstart. The resulting installed system
is a normal writable Fedora installation.

```bash
./build-iso.sh
```

Set `FEDORA_KDE_ISO=/path/to/Fedora-KDE-Desktop-Live-x86_64.iso` to use a local
base ISO. If it is not set, the script downloads the Fedora 44 KDE Live ISO;
override `FEDORA_RELEASE`, `FEDORA_KDE_VERSION`, or
`FEDORA_KDE_ISO_URL` when Fedora publishes a new release.

The customized ISO is written below `output/`. Test it in a virtual machine
before installing it on a physical disk. The bundled Kickstart does not clear
your disks automatically; choose the target storage in Anaconda.

The booted installer/live session uses a compressed temporary filesystem, as
normal live media does. That temporary session is not the installed Spider OS;
after Anaconda writes to disk, the installed root is ordinary writable Fedora
storage and is checked by `tests/verify-installed-system.sh`.

## Run source checks

```bash
./tests/test-tree.sh
```

The native C++ components can also be built directly on a Qt6 development
machine:

```bash
cmake -S native -B native-build -G Ninja -DCMAKE_BUILD_TYPE=Debug
cmake --build native-build
```

## Verify an installed system

After booting a system made from this image, run:

```bash
./tests/verify-installed-system.sh
```

Or use the installed commands:

```bash
systemctl status spider-os.service
spiderctl status
```

An installed system is healthy only when the systemd unit is active, the
resident Unix socket exists, `spiderctl status` reports `native: true` and
`state: ready`, and the root filesystem is writable.

## Repository rule

This source tree is the native replacement foundation. Do not copy the old web
application into it to restore a feature. New features must arrive as a native
service, native KDE/Qt component, or an explicitly isolated container.

See [ROADMAP.md](ROADMAP.md) for the native-only sequence for Webbie, local
search, creative tools, VS Code, and Kali Bay.
