# Spider OS native roadmap

## 0.1 — Writable native foundation (this restart)

- Traditional mutable Fedora KDE installation.
- Real Anaconda-based installer ISO.
- Native `spiderd`, `spiderctl`, and Qt6 `spider-shell`.
- Webbie presence over a local Unix socket.
- Crimson Spider branding and KDE session integration.
- Source and installed-system checks that reject read-only deployments.

## 0.2 — Resident Webbie

- Expand `spiderd` into the resident Webbie process.
- Add a native KDE/Qt conversation surface to `spider-shell`.
- Keep model/provider credentials outside the image and opt-in.
- Add Australian voice as a user-selectable desktop capability.
- Preserve offline desktop use when Webbie is unavailable.

## 0.3 — The Web and local search

- Replace the old browser-shaped command center with native Qt views.
- Add a local search/index service with an explicit permission boundary.
- Expose search results to Webbie without granting arbitrary host execution.
- Add indexing controls, pause/resume, and a visible data directory.

## 0.4 — Creative workstation

- Add audio, graphics, tattoo-design, coding, and media packages as normal
  mutable Fedora packages or user-installed applications.
- Add a tested VS Code installation path and a visible repair command.
- Keep large optional stacks out of the base installer when they are not needed.

## 0.5 — Kali Bay and qualification

- Add the isolated Kali workspace as an explicit, opt-in container boundary.
- Boot the ISO in QEMU, install it to a writable virtual disk, eject the ISO,
  reboot from disk, and verify KDE, Webbie, the native shell, and writability.
- Capture service status and journal output when qualification fails.

