#!/usr/bin/env bash
set -Eeuo pipefail

project_root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
output_root="${1:-$project_root/output/spider-native-root}"
build_dir="$project_root/native-build"

for command_name in cmake ninja g++; do
  if ! command -v "$command_name" >/dev/null 2>&1; then
    printf 'Missing build tool: %s\n' "$command_name" >&2
    printf '%s\n' 'Install cmake, gcc-c++, ninja-build, and qt6-qtbase-devel on Fedora.' >&2
    exit 1
  fi
done

if ! command -v pkg-config >/dev/null 2>&1 || ! pkg-config --exists Qt6Widgets; then
  printf '%s\n' 'Qt6 Widgets development files are missing.' >&2
  printf '%s\n' 'Install qt6-qtbase-devel on Fedora, then run this script again.' >&2
  exit 1
fi

mkdir -p "$project_root/output"
rm -rf "$build_dir" "$output_root"

cmake -S "$project_root/native" -B "$build_dir" \
  -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX=/usr
cmake --build "$build_dir" --parallel

DESTDIR="$output_root" cmake --install "$build_dir"
cp -a "$project_root/system_files/." "$output_root/"

printf 'Native Spider OS payload: %s\n' "$output_root"

