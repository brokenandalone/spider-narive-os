# Spider OS writable Fedora/KDE installer profile.
# This is intentionally a normal Anaconda installation. The native payload is
# added to the ISO at /spider-native-root.

lang en_US.UTF-8
keyboard --xlayouts='us'
timezone America/New_York --utc
selinux --enforcing
firewall --enabled
rootpw --lock
firstboot --enable
bootloader --timeout=1
zerombr
liveimg --url=file:///run/install/repo/LiveOS/squashfs.img
services --enabled=NetworkManager,sddm
reboot

%packages
@kde-desktop-environment
NetworkManager-wifi
NetworkManager-tui
firewalld
konsole
plasma-discover
systemd
sudo
%end

%post --nochroot
set -eux

payload=/run/install/repo/spider-native-root
target=/mnt/sysroot

test -d "$payload"
test -d "$target"
cp -a "$payload"/. "$target"/

chroot "$target" /usr/bin/systemd-sysusers
chroot "$target" /usr/bin/systemctl enable spider-os.service
chroot "$target" /usr/bin/systemctl enable sddm.service

%end
