#include <QApplication>
#include <QDesktopServices>
#include <QDir>
#include <QFrame>
#include <QHBoxLayout>
#include <QLabel>
#include <QMainWindow>
#include <QMessageBox>
#include <QProcess>
#include <QPushButton>
#include <QTimer>
#include <QUrl>
#include <QVBoxLayout>
#include <QWidget>

#include <QStringList>

#include <functional>

#ifndef SPIDER_VERSION
#define SPIDER_VERSION "0.1.0"
#endif

namespace {

class SpiderShell final : public QMainWindow {
 public:
  SpiderShell() {
    setWindowTitle(QStringLiteral("Spider OS — The Web"));
    setMinimumSize(760, 480);
    resize(920, 600);

    auto* central = new QWidget(this);
    auto* root = new QVBoxLayout(central);
    root->setContentsMargins(42, 34, 42, 34);
    root->setSpacing(20);

    auto* heading = new QLabel(QStringLiteral("SPIDER OS"), central);
    heading->setObjectName(QStringLiteral("heading"));
    auto* tagline = new QLabel(QStringLiteral("YOUR LIFE. ONE WEB."), central);
    tagline->setObjectName(QStringLiteral("tagline"));
    root->addWidget(heading);
    root->addWidget(tagline);

    auto* statusCard = new QFrame(central);
    statusCard->setObjectName(QStringLiteral("statusCard"));
    auto* statusLayout = new QVBoxLayout(statusCard);
    statusLayout->setContentsMargins(24, 20, 24, 20);
    auto* statusEyebrow = new QLabel(QStringLiteral("RESIDENT CORE"), statusCard);
    statusEyebrow->setObjectName(QStringLiteral("eyebrow"));
    statusTitle_ = new QLabel(QStringLiteral("Checking Webbie…"), statusCard);
    statusTitle_->setObjectName(QStringLiteral("statusTitle"));
    statusDetail_ = new QLabel(QStringLiteral("Waiting for spider-os.service"), statusCard);
    statusDetail_->setObjectName(QStringLiteral("statusDetail"));
    statusLayout->addWidget(statusEyebrow);
    statusLayout->addWidget(statusTitle_);
    statusLayout->addWidget(statusDetail_);
    root->addWidget(statusCard);

    auto* actionLabel = new QLabel(QStringLiteral("NATIVE DESKTOP"), central);
    actionLabel->setObjectName(QStringLiteral("eyebrow"));
    root->addWidget(actionLabel);

    auto* actions = new QHBoxLayout();
    actions->setSpacing(12);
    addAction(actions, QStringLiteral("Files"), [this] {
      QDesktopServices::openUrl(QUrl::fromLocalFile(QDir::homePath()));
    });
    addAction(actions, QStringLiteral("Terminal"), [] {
      QProcess::startDetached(QStringLiteral("konsole"));
    });
    addAction(actions, QStringLiteral("Settings"), [] {
      QProcess::startDetached(QStringLiteral("systemsettings"));
    });
    addAction(actions, QStringLiteral("Health Check"), [this] {
      showHealthReport();
    });
    root->addLayout(actions);
    root->addStretch(1);

    auto* footer = new QLabel(
        QStringLiteral("Native foundation %1 · KDE Plasma · writable Fedora")
            .arg(QStringLiteral(SPIDER_VERSION)),
        central);
    footer->setObjectName(QStringLiteral("footer"));
    root->addWidget(footer);

    setCentralWidget(central);
    setStyleSheet(QStringLiteral(
        "QMainWindow { background: #111114; color: #f0ece4; }"
        "QWidget { color: #f0ece4; font-family: 'Noto Sans', sans-serif; }"
        "QLabel#heading { color: #c92d3f; font-size: 38px; font-weight: 800; letter-spacing: 4px; }"
        "QLabel#tagline { color: #a6a1a0; font-size: 13px; letter-spacing: 3px; }"
        "QLabel#eyebrow { color: #c92d3f; font-size: 11px; font-weight: 700; letter-spacing: 2px; }"
        "QFrame#statusCard { background: #1b1b20; border: 1px solid #37333a; border-radius: 12px; }"
        "QLabel#statusTitle { color: #f0ece4; font-size: 24px; font-weight: 700; margin-top: 8px; }"
        "QLabel#statusDetail { color: #aaa5a3; font-size: 13px; margin-top: 2px; }"
        "QPushButton { background: #24232a; border: 1px solid #46414a; border-radius: 8px; padding: 13px 18px; color: #f0ece4; font-size: 13px; }"
        "QPushButton:hover { background: #332831; border-color: #c92d3f; }"
        "QPushButton:pressed { background: #4b202b; }"
        "QLabel#footer { color: #706b70; font-size: 11px; }"));

    auto* timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, [this] { refreshStatus(); });
    timer->start(4000);
    refreshStatus();
  }

 private:
  void addAction(QHBoxLayout* layout, const QString& label,
                 const std::function<void()>& action) {
    auto* button = new QPushButton(label, centralWidget());
    connect(button, &QPushButton::clicked, this, action);
    layout->addWidget(button);
  }

  void refreshStatus() {
    QProcess command;
    command.start(QStringLiteral("/usr/bin/spiderctl"), {QStringLiteral("status")});
    if (!command.waitForFinished(1500)) {
      command.kill();
      statusTitle_->setText(QStringLiteral("Webbie is offline"));
      statusDetail_->setText(QStringLiteral("spider-os.service did not answer"));
      return;
    }

    const QString output = QString::fromUtf8(command.readAllStandardOutput());
    const bool ready = command.exitCode() == 0 && output.contains(QStringLiteral("\"state\":\"ready\""));
    if (ready) {
      statusTitle_->setText(QStringLiteral("Webbie is resident"));
      statusDetail_->setText(QStringLiteral("Native Unix socket · spider-os.service ready"));
    } else {
      statusTitle_->setText(QStringLiteral("Webbie is offline"));
      statusDetail_->setText(QStringLiteral("Start spider-os.service, then check again"));
    }
  }

  void showHealthReport() {
    QProcess command;
    command.start(QStringLiteral("/usr/bin/spiderctl"), {QStringLiteral("health")});
    command.waitForFinished(1500);
    QString report = QString::fromUtf8(command.readAllStandardOutput());
    if (report.isEmpty()) {
      report = QString::fromUtf8(command.readAllStandardError());
    }
    if (report.isEmpty()) {
      report = QStringLiteral("No response from the resident service.");
    }
    QMessageBox::information(this, QStringLiteral("Spider OS health"), report);
  }

  QLabel* statusTitle_{};
  QLabel* statusDetail_{};
};

}  // namespace

int main(int argc, char* argv[]) {
  QApplication application(argc, argv);
  QApplication::setApplicationName(QStringLiteral("Spider OS"));
  QApplication::setApplicationDisplayName(QStringLiteral("Spider OS"));
  QApplication::setApplicationVersion(QStringLiteral(SPIDER_VERSION));

  SpiderShell shell;
  shell.show();
  return application.exec();
}
