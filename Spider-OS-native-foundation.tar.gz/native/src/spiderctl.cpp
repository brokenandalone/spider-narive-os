#include <cerrno>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <iostream>
#include <string>
#include <string_view>

#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#ifndef SPIDER_VERSION
#define SPIDER_VERSION "0.1.0"
#endif

namespace {
constexpr std::string_view kSocketPath = "/run/spider-os/webbie.sock";

bool send_all(int fd, std::string_view message) {
  std::size_t sent = 0;
  while (sent < message.size()) {
    const ssize_t count = ::write(fd, message.data() + sent, message.size() - sent);
    if (count < 0) {
      if (errno == EINTR) {
        continue;
      }
      return false;
    }
    sent += static_cast<std::size_t>(count);
  }
  return true;
}
}

int main(int argc, char** argv) {
  if (argc > 1 && (std::string_view(argv[1]) == "--version" ||
                   std::string_view(argv[1]) == "-v")) {
    std::cout << "spiderctl " << SPIDER_VERSION << '\n';
    return 0;
  }

  const std::string command = argc > 1 ? argv[1] : "status";
  if (command != "status" && command != "health" && command != "ping" &&
      command != "hello") {
    std::cerr << "Usage: spiderctl [status|health|ping|hello]\n";
    return 2;
  }

  const int client = ::socket(AF_UNIX, SOCK_STREAM, 0);
  if (client < 0) {
    std::perror("spiderctl: socket");
    return 3;
  }

  const int flags = ::fcntl(client, F_GETFD);
  if (flags >= 0) {
    ::fcntl(client, F_SETFD, flags | FD_CLOEXEC);
  }

  sockaddr_un address{};
  address.sun_family = AF_UNIX;
  std::memcpy(address.sun_path, kSocketPath.data(), kSocketPath.size());
  if (::connect(client, reinterpret_cast<const sockaddr*>(&address), sizeof(address)) < 0) {
    std::cerr << "Spider OS resident service is offline: " << std::strerror(errno)
              << '\n';
    ::close(client);
    return 3;
  }

  if (!send_all(client, command + "\n")) {
    std::perror("spiderctl: write");
    ::close(client);
    return 3;
  }

  char buffer[1024]{};
  while (true) {
    const ssize_t count = ::read(client, buffer, sizeof(buffer));
    if (count == 0) {
      break;
    }
    if (count < 0) {
      if (errno == EINTR) {
        continue;
      }
      std::perror("spiderctl: read");
      ::close(client);
      return 3;
    }
    std::cout.write(buffer, count);
  }

  ::close(client);
  return 0;
}
