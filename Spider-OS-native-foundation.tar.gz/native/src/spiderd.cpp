#include <atomic>
#include <cerrno>
#include <csignal>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fcntl.h>
#include <fstream>
#include <iostream>
#include <poll.h>
#include <string>
#include <string_view>

#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <unistd.h>

#ifndef SPIDER_VERSION
#define SPIDER_VERSION "0.1.0"
#endif

namespace {

constexpr std::string_view kRunDirectory = "/run/spider-os";
constexpr std::string_view kSocketPath = "/run/spider-os/webbie.sock";
constexpr std::string_view kStatusPath = "/run/spider-os/status.json";
constexpr std::string_view kReadyPath = "/run/spider-os/ready";

volatile std::sig_atomic_t g_running = 1;

void stop_handler(int) {
  g_running = 0;
}

std::string trim_command(std::string value) {
  while (!value.empty() && (value.back() == '\n' || value.back() == '\r' ||
                            value.back() == ' ' || value.back() == '\t')) {
    value.pop_back();
  }
  std::size_t first = 0;
  while (first < value.size() && (value[first] == ' ' || value[first] == '\t')) {
    ++first;
  }
  return value.substr(first);
}

std::string status_json() {
  return std::string{"{\"service\":\"spider-os\",\"resident\":\"webbie\",\"state\":\"ready\",\"native\":true,\"transport\":\"unix\",\"version\":\""} +
         SPIDER_VERSION + "\"}\n";
}

bool write_text_file(std::string_view path, std::string_view contents) {
  const std::string temporary = std::string(path) + ".tmp";
  {
    std::ofstream output(temporary, std::ios::trunc);
    if (!output) {
      return false;
    }
    output << contents;
    output.flush();
    if (!output) {
      return false;
    }
  }
  if (::rename(temporary.c_str(), std::string(path).c_str()) != 0) {
    ::unlink(temporary.c_str());
    return false;
  }
  return true;
}

bool send_all(int fd, std::string_view message) {
  std::size_t sent = 0;
  while (sent < message.size()) {
    const ssize_t count = ::write(fd, message.data() + sent, message.size() - sent);
    if (count < 0) {
      if (errno == EINTR) {
        continue;
      }
      return false;
    }
    sent += static_cast<std::size_t>(count);
  }
  return true;
}

std::string response_for(std::string command) {
  command = trim_command(std::move(command));
  if (command == "status" || command == "health") {
    return status_json();
  }
  if (command == "ping") {
    return "pong\n";
  }
  if (command == "hello") {
    return "Webbie is resident in Spider OS.\n";
  }
  return "error: unsupported command\n";
}

int make_server_socket() {
  const int server = ::socket(AF_UNIX, SOCK_STREAM, 0);
  if (server < 0) {
    std::perror("spiderd: socket");
    return -1;
  }

  sockaddr_un address{};
  address.sun_family = AF_UNIX;
  if (kSocketPath.size() >= sizeof(address.sun_path)) {
    std::cerr << "spiderd: socket path is too long\n";
    ::close(server);
    return -1;
  }
  std::memcpy(address.sun_path, kSocketPath.data(), kSocketPath.size());

  ::unlink(kSocketPath.data());
  if (::bind(server, reinterpret_cast<const sockaddr*>(&address), sizeof(address)) < 0) {
    std::perror("spiderd: bind");
    ::close(server);
    return -1;
  }
  // The protocol is status-only in this milestone. Keep it local to the host
  // and readable by desktop users so spider-shell can query it without root.
  if (::chmod(kSocketPath.data(), 0666) < 0) {
    std::perror("spiderd: chmod");
    ::close(server);
    ::unlink(kSocketPath.data());
    return -1;
  }
  if (::listen(server, 16) < 0) {
    std::perror("spiderd: listen");
    ::close(server);
    ::unlink(kSocketPath.data());
    return -1;
  }
  return server;
}

void serve_client(int client) {
  char buffer[512]{};
  const ssize_t count = ::read(client, buffer, sizeof(buffer) - 1);
  if (count > 0) {
    buffer[count] = '\0';
    const std::string response = response_for(buffer);
    send_all(client, response);
  }
  ::close(client);
}

}  // namespace

int main() {
  std::signal(SIGTERM, stop_handler);
  std::signal(SIGINT, stop_handler);
  std::signal(SIGPIPE, SIG_IGN);

  try {
    std::filesystem::create_directories(kRunDirectory);
  } catch (const std::filesystem::filesystem_error& error) {
    std::cerr << "spiderd: cannot create runtime directory: " << error.what() << '\n';
    return 1;
  }

  const std::string status = status_json();
  if (!write_text_file(kStatusPath, status) ||
      !write_text_file(kReadyPath, "ready\n")) {
    std::cerr << "spiderd: cannot write readiness state\n";
    return 1;
  }

  const int server = make_server_socket();
  if (server < 0) {
    ::unlink(kStatusPath.data());
    ::unlink(kReadyPath.data());
    return 1;
  }

  std::cout << "Spider OS resident service ready on " << kSocketPath << '\n';
  while (g_running) {
    pollfd descriptor{server, POLLIN, 0};
    const int result = ::poll(&descriptor, 1, 1000);
    if (result < 0) {
      if (errno == EINTR) {
        continue;
      }
      std::perror("spiderd: poll");
      break;
    }
    if (result > 0 && (descriptor.revents & POLLIN) != 0) {
      const int client = ::accept(server, nullptr, nullptr);
      if (client >= 0) {
        const int flags = ::fcntl(client, F_GETFD);
        if (flags >= 0) {
          ::fcntl(client, F_SETFD, flags | FD_CLOEXEC);
        }
        serve_client(client);
      } else if (errno != EINTR) {
        std::perror("spiderd: accept");
      }
    }
  }

  ::close(server);
  ::unlink(kSocketPath.data());
  ::unlink(kStatusPath.data());
  ::unlink(kReadyPath.data());
  return 0;
}
