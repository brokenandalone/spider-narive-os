#!/usr/bin/env bash
set -Eeuo pipefail

project_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
failures=0

fail() {
  printf 'FAIL: %s\n' "$*" >&2
  failures=$((failures + 1))
}

for script in "$project_root"/*.sh "$project_root"/tools/*.sh "$project_root"/tests/*.sh; do
  [[ -f "$script" ]] || continue
  bash -n "$script" || fail "shell syntax: ${script#$project_root/}"
done

if rg -n -i --glob '!README.md' --glob '!ARCHITECTURE.md' --glob '!tests/test-tree.sh' \
  '(electron|webengine|index\.html|npm run|127\.0\.0\.1|localhost:[0-9])' \
  "$project_root/native" "$project_root/system_files" "$project_root/installer" \
  "$project_root"/*.sh "$project_root"/tools "$project_root"/tests >/tmp/spider-os-web-regressions 2>/dev/null; then
  sed 's#^#  #' /tmp/spider-os-web-regressions >&2
  fail 'web-shell dependency found in the native source tree'
fi

if rg -n -i --glob '!tests/test-tree.sh' '(bootc[[:space:]]+(switch|install)|rpm-ostree|ostreecontainer|ghcr\.io/ublue-os)' \
  "$project_root/native" "$project_root/system_files" "$project_root/installer" \
  "$project_root"/*.sh "$project_root"/tools "$project_root"/tests "$project_root"/.github; then
  fail 'immutable/Atomic build path found in the writable native source tree'
fi

if command -v g++ >/dev/null 2>&1; then
  g++ -std=c++17 -DSPIDER_VERSION='"0.1.0"' -Wall -Wextra -Wpedantic \
    -fsyntax-only "$project_root/native/src/spiderd.cpp" \
    || fail 'spiderd C++ syntax'
  g++ -std=c++17 -DSPIDER_VERSION='"0.1.0"' -Wall -Wextra -Wpedantic \
    -fsyntax-only "$project_root/native/src/spiderctl.cpp" \
    || fail 'spiderctl C++ syntax'
fi

if command -v pkg-config >/dev/null 2>&1 && pkg-config --exists Qt6Widgets; then
  # shellcheck disable=SC2046
  g++ -std=c++17 -DSPIDER_VERSION='"0.1.0"' -Wall -Wextra -Wpedantic \
    $(pkg-config --cflags Qt6Widgets) \
    -fsyntax-only "$project_root/native/src/spider-shell.cpp" \
    || fail 'spider-shell C++ syntax'
else
  printf '%s\n' 'SKIP: Qt6Widgets development files are not installed; shell syntax is checked in CI.'
fi

required_service_keys=(
  'User=spider'
  'RestrictAddressFamilies=AF_UNIX'
  'ExecStart=/usr/libexec/spider-os/spiderd'
  'WantedBy=multi-user.target'
)
for key in "${required_service_keys[@]}"; do
  rg -q -F "$key" "$project_root/system_files/usr/lib/systemd/system/spider-os.service" \
    || fail "systemd unit missing $key"
done

rm -f /tmp/spider-os-web-regressions

if (( failures > 0 )); then
  printf '%d source check(s) failed.\n' "$failures" >&2
  exit 1
fi

printf '%s\n' 'PASS: native Spider OS source tree checks passed.'
