#!/usr/bin/env bash
set -Eeuo pipefail

fail() {
  printf 'FAIL: %s\n' "$*" >&2
  exit 1
}

if [[ "$EUID" -ne 0 ]]; then
  printf '%s\n' 'Run this check as root on the installed Spider OS system.' >&2
  exit 2
fi

root_options="$(findmnt -no OPTIONS / 2>/dev/null || true)"
if printf '%s\n' "$root_options" | tr ',' '\n' | grep -qx 'ro'; then
  fail "root filesystem is mounted read-only ($root_options)"
fi
[[ -w /etc ]] || fail '/etc is not writable'
[[ -w /usr ]] || fail '/usr is not writable'

systemctl is-enabled --quiet spider-os.service || fail 'spider-os.service is not enabled'
systemctl is-active --quiet spider-os.service || fail 'spider-os.service is not active'
[[ -S /run/spider-os/webbie.sock ]] || fail 'Webbie Unix socket is missing'
[[ -f /run/spider-os/ready ]] || fail 'Webbie readiness marker is missing'

status="$(spiderctl status)" || fail 'spiderctl status did not answer'
[[ "$status" == *'"native":true'* ]] || fail 'resident service did not report native=true'
[[ "$status" == *'"state":"ready"'* ]] || fail 'resident service did not report state=ready'
command -v spider-shell >/dev/null 2>&1 || fail 'spider-shell is not installed'
[[ -f /etc/xdg/autostart/spider-shell.desktop ]] || fail 'KDE native shell autostart file is missing'

printf '%s\n' 'PASS: writable native Spider OS installation is healthy.'

