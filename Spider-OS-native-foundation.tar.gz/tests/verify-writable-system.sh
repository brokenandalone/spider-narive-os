#!/usr/bin/env bash
set -Eeuo pipefail

fail() {
  printf 'FAIL: %s\n' "$*" >&2
  exit 1
}

if [[ "$EUID" -ne 0 ]]; then
  printf '%s\n' 'Run this check as root so filesystem writability is measured correctly.' >&2
  exit 2
fi

root_options="$(findmnt -no OPTIONS / 2>/dev/null || true)"
if printf '%s\n' "$root_options" | tr ',' '\n' | grep -qx 'ro'; then
  fail "root filesystem is mounted read-only ($root_options)"
fi
[[ -w /etc ]] || fail '/etc is not writable'
[[ -w /usr ]] || fail '/usr is not writable'

printf '%s\n' 'PASS: root, /etc, and /usr are writable.'
