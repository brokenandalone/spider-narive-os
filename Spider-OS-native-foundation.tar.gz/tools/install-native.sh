#!/usr/bin/env bash
set -Eeuo pipefail

project_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
payload="${1:-$project_root/output/spider-native-root}"

if [[ "$EUID" -ne 0 ]]; then
  exec sudo -- "$0" "$@"
fi

if [[ ! -d "$payload" ]]; then
  printf 'Native payload not found: %s\n' "$payload" >&2
  printf '%s\n' 'Run ./build-native.sh first.' >&2
  exit 1
fi

if [[ ! -w /etc || ! -w /usr ]]; then
  printf '%s\n' 'Refusing to install: the target system is not writable.' >&2
  printf '%s\n' 'Spider OS native installs require a normal writable Fedora root filesystem.' >&2
  exit 1
fi

cp -a "$payload"/. /
systemd-sysusers
systemctl daemon-reload
systemctl enable --now spider-os.service

printf '%s\n' 'Native Spider OS components installed and spider-os.service started.'

